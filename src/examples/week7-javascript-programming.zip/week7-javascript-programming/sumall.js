function sumall(num) {
  // returns the sum of all numbers smaller than or equal to num
  return -1;
}

module.exports = sumall;
