function smush(a, b) {
  // merges the two lists a and b by taking alternate elements from each list in turn

}

module.exports = smush;
