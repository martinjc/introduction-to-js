function sumall35(high) {
  // should return the sum of all multiples of 3 and 5 below high, or -1 if high is not a number
  if (typeof high != "number") {
    return -1;
  }
}

module.exports = sumall35;
