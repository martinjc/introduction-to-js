function middle(input) {
    // accepts a string as input, returns the middle character (if length is odd) or the middle two characters (if length is even)
}

module.exports = middle;