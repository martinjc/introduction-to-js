function even_or_odd(num) {
  // returns 'even' if the number given is even, or 'odd' if the number given is odd.
  return undefined;
}

module.exports = even_or_odd;
