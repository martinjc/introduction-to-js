let x = "5";
let y = -10;

if(x < y) {
    console.log("x is less than y");
} else if(x > y){
    console.log("x is greater than y");
} else {
    console.log("x is equal to y");
}


if(x == "5") {
    console.log("x is equal to \"5\"");
}

if(x === "5") {
    console.log("x is strongly equal to \"5\"");
}

if(undefined) {
    console.log("undefined is true");
} else {
    console.log("undefined is false");
}
