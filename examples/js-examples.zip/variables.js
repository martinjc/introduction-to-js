const z = 22;

z = 35;

let x = 5;

if(true) {
    let y = 6;
}

console.log(x);
console.log(y);
