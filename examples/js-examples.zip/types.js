let x = 5;
let y = -10;
let z = 4.65;

console.log(x);
console.log(typeof(x));


let name = "arthur";
console.log(typeof(name));

let t = true;
let f = false;

console.log(typeof(t));

let notDefined;

console.log(notDefined);
console.log(typeof(notDefined));

let cantCodeJS = null;

console.log(cantCodeJS);
console.log(typeof(cantCodeJS));
